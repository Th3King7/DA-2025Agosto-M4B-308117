package DDA._7.obligatorio.modelo;

public class Tarifa {
private int monto;
private Categoria categoria;

public Tarifa(int monto, Categoria categoria) {
    this.monto = monto;
    this.categoria = categoria;
}

public int getMonto() {
    return monto;
}

public Categoria getCategoria() {
    return categoria;
}

}
