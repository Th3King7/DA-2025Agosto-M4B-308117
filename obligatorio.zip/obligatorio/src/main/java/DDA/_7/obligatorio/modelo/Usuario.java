package DDA._7.obligatorio.modelo;

public abstract class Usuario {
private String ci;
    private String nombreCompleto;
     private String password;

    public Usuario(String ci, String password, String nombreCompleto) {
        this.ci = ci;
        this.password = password;
        this.nombreCompleto = nombreCompleto;
    }

    public String getNombre() {
        return ci;
    }

    public String getNombreCompleto() {
        return nombreCompleto;
    }

  
    public String getPassword() {
        return password;
    }

    @Override
    public String toString() {
        return nombreCompleto;
    }
}
