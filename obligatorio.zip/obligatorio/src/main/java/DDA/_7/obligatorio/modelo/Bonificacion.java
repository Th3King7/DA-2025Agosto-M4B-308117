package DDA._7.obligatorio.modelo;

public class Bonificacion {
private String nombre;

public Bonificacion(String nombre) {
    this.nombre = nombre;
}
public String getNombre() {
    return nombre;
}
}
