package DDA._7.obligatorio.modelo;

public class Categoria {
private String nombre;
public Categoria(String nombre) {
    this.nombre = nombre;
}
public String getNombre() {
    return nombre;
}
}
