/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DDA._7.obligatorio.modelo;
/**
 *
 * @author PC
 */
public class PeajeException extends Exception{

    public PeajeException(String message) {
        super(message);
    }
    
    
    
}
