package DDA._7.obligatorio.modelo;

public class SistemaUsuarios {

}
