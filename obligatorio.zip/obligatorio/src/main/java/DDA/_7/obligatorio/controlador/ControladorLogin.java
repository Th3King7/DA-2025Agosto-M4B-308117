package DDA._7.obligatorio.controlador;
import java.util.List;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import DDA._7.obligatorio.modelo.Administrador;
import DDA._7.obligatorio.modelo.Fachada;
import DDA._7.obligatorio.modelo.PeajeException;
import DDA._7.obligatorio.modelo.Sesion;
import jakarta.servlet.http.HttpSession;


@RestController
@RequestMapping("/acceso")

public class ControladorLogin {

    @PostMapping("/loginPropietario")
    public List<Respuesta> loginPropietario(HttpSession sesionHttp, @RequestParam String ci, @RequestParam String password) throws PeajeException {
        
        //login al modelo
        Sesion sesion  = Fachada.getInstancia().loginPropietario(ci, password);
        

        //si hay una sesion activa la cierro
        logoutPropietario(sesionHttp);

        //guardo la sesion de la logica en la sesionHttp
        sesionHttp.setAttribute("usuarioTablero", sesion);
        return Respuesta.lista(new Respuesta("loginExitoso", "menu-propietario.html"));
    }

    @PostMapping("/loginAdmin")
    public List<Respuesta> loginAdministrador(HttpSession sesionHttp, @RequestParam String ci, @RequestParam String password) throws PeajeException {
        //login al modelo
        Administrador admin = Fachada.getInstancia().loginAdministrador(ci, password);
                
        //guardo el admin en la sesionHttp
        sesionHttp.setAttribute("usuarioAdmin", admin);
        return Respuesta.lista(new Respuesta("loginExitoso", "monitor-actividad.html"));
    }

    @PostMapping("/logoutAgenda")
    public List<Respuesta> logoutPropietario(HttpSession sesionHttp) throws PeajeException {
        Sesion sesion = (Sesion)sesionHttp.getAttribute("usuarioPropietario");
        if(sesion!=null){
            Fachada.getInstancia().logout(sesion);
            sesionHttp.removeAttribute("usuarioPropietario");
            
            
        }
        return Respuesta.lista(new Respuesta("paginaLogin", "login-propietario.html"));

    }

}
