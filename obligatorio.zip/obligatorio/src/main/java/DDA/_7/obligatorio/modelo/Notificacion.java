package DDA._7.obligatorio.modelo;

public class Notificacion {
private String mensaje;
private String fecha;
public Notificacion(String mensaje) {
    this.mensaje = mensaje;
    this.fecha = java.time.LocalDate.now().toString();
}
public String getMensaje() {
    return mensaje;
}
public String getFecha() {
    return fecha;
}

}
