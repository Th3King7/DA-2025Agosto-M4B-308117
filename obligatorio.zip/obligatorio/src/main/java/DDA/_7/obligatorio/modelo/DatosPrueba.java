/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DDA._7.obligatorio.modelo;

import java.util.ArrayList;

/**
 *
 * @author PC
 */
public class DatosPrueba {
    
    public static void cargar(){
        Fachada fachada = Fachada.getInstancia();

        //USUARIOS
        // Crear administrador
        fachada.agregarAdministrador("12345678", "admin.123", "Usuario Administrador");

        // Crear propietario
        ArrayList<Vehiculo> vehiculos = new ArrayList<>();
        ArrayList<Asignacion> asignaciones = new ArrayList<>();
        ArrayList<Notificacion> notificaciones = new ArrayList<>();
        fachada.agregarUsuarioPropietario("23456789", "prop.123", "Usuario Propietario", 2000, 500, vehiculos, asignaciones, notificaciones);
}
}
