/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DDA._7.obligatorio.modelo;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author PC
 */
public class SistemaAcceso {
    
    private ArrayList<Propietario> propietarios = new ArrayList();
    private ArrayList<Administrador> administradores = new ArrayList();
    private ArrayList<Sesion> sesiones = new ArrayList();
    
    public void agregarUsuarioPropietario(String ci, String password, String nombreCompleto, double saldoActual, double salodMinimoAlerta, List<Vehiculo> vehiculos, List<Asignacion> asignacionBonifiaciones, List<Notificacion> notificaciones){
        propietarios.add(new Propietario( ci,  password,  nombreCompleto,  saldoActual,  salodMinimoAlerta, vehiculos, asignacionBonifiaciones,  notificaciones, new Habilitado()));
    }
     public void agregarAdministrador(String ci,String pwd,String nombreCompleto){
        administradores.add(new Administrador(ci, pwd, nombreCompleto));
    }


   public Sesion loginPropietario(String ci,String pwd) throws PeajeException{
        
       Sesion sesion = null;
       Propietario usuario = (Propietario) login(ci, pwd, propietarios);
       if(usuario!=null){
           sesion = new Sesion(usuario);
           sesiones.add(sesion);
           Fachada.getInstancia().avisar(Fachada.Eventos.listaSesiones);
           return sesion;
       }
       throw new PeajeException("Login incorrecto");
       
    }
     public Administrador loginAdministrador(String ci,String pwd) throws PeajeException{
       Administrador admin =  (Administrador) login(ci, pwd, administradores);
       if(admin==null) throw new PeajeException("Login incorrecto");
       return admin;
    }
    
     private Usuario login(String ci, String pwd, ArrayList lista){
        Usuario usuario;
        
        for(Object o:lista){
            usuario = (Usuario)o;
            if(usuario.getNombre().equals(ci) && usuario.getPassword().equals(pwd)){
                return usuario;
            }
        }
        return null;
    }

    public ArrayList<Sesion> getSesiones() {
        return sesiones;
    }
    
    public void logout(Sesion s){
        sesiones.remove(s);
        Fachada.getInstancia().avisar(Fachada.Eventos.listaSesiones);
       
    }
}
