package DDA._7.obligatorio.modelo;

import java.util.List;

import DDA._7.obligatorio.observador.Observable;

public class TableroPropietario extends Observable{

    private String nombrePropietario;
    private String estado;
    private double saldoActual;
    private List<Asignacion> bonificaciones;
    private List<Vehiculo> vehiculos;
    private List<Transito> transitos;
    private List<Notificacion> notificaciones;

    public TableroPropietario(Propietario propietario) {
        this.nombrePropietario = propietario.getNombreCompleto();
        this.estado = propietario.getEstado().getNombreEstado();
        this.saldoActual = propietario.getSaldoActual();
        this.bonificaciones = propietario.getAsignacionBonifiaciones();
        this.vehiculos = propietario.getVehiculos();
        this.transitos = propietario.getTransitos();
        this.notificaciones = propietario.getNotificaciones();
    }
    
    
}
