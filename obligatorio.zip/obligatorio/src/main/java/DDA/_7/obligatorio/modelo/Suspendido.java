package DDA._7.obligatorio.modelo;

public class Suspendido extends Estado {
    public Suspendido() {
        super("Suspendido");
    }

    @Override
    public void ingresar(Propietario p) throws Exception {
        throw new Exception("El propietario está suspendido y no puede ingresar al sistema.");
    }

    @Override
    public boolean puedeTransitar() {
        return false;
    }

    @Override
    public boolean aplicaBonificacion() {
        return false;
    }

}
