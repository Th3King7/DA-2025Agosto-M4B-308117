package DDA._7.obligatorio.controlador;

import java.util.List;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import DDA._7.obligatorio.modelo.Fachada;
import DDA._7.obligatorio.modelo.Propietario;
import DDA._7.obligatorio.modelo.Sesion;
import DDA._7.obligatorio.modelo.TableroPropietario;
import jakarta.servlet.http.HttpSession;

@RestController
@RequestMapping("/propietario")
public class ControladorPropietario {

    @PostMapping("/obtenerTablero")
    public TableroPropietario obtenerTablero(HttpSession sesionHttp) {
        // Obtener la sesion guardada en el login (clave usada por ControladorLogin)
        Sesion sesion = (Sesion) sesionHttp.getAttribute("usuarioTablero");
        if (sesion == null) {
            // intentar con otra clave que pudiera usarse en el proyecto
            sesion = (Sesion) sesionHttp.getAttribute("usuarioPropietario");
        }
        if (sesion == null) {
            // Sin validaciones pedidas por el usuario, devolvemos null si no hay sesion
            return null;
        }
        Propietario propietario = sesion.getUsuario();
        return Fachada.getInstancia().getTableroPropietario(propietario);
    }

    @PostMapping("/borrarNotificaciones")
    public List<Respuesta> borrarNotificaciones(HttpSession sesionHttp) {
        Sesion sesion = (Sesion) sesionHttp.getAttribute("usuarioTablero");
        if (sesion == null) sesion = (Sesion) sesionHttp.getAttribute("usuarioPropietario");
        if (sesion != null) {
            Propietario propietario = sesion.getUsuario();
            if (propietario.getNotificaciones() != null) {
                propietario.getNotificaciones().clear();
            }
        }
        return Respuesta.lista(new Respuesta("notificacionesBorradas", "Notificaciones borradas"));
    }

}


