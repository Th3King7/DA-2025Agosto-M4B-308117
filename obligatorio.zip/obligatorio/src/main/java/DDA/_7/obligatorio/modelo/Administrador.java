package DDA._7.obligatorio.modelo;

public class Administrador extends Usuario {
    public Administrador(String ci, String password, String nombreCompleto) {
        super(ci, password, nombreCompleto);
    }
}
