package DDA._7.obligatorio.modelo;

import java.util.List;

public class Puesto {
private String nombre;
private String direccion;
private List<Tarifa> tarifas;

public Puesto(String nombre, String direccion) {
    this.nombre = nombre;
    this.direccion = direccion;
}

public String getNombre() {
    return nombre;
}

public String getDireccion() {
    return direccion;
}

public List<Tarifa> getTarifas() {
    return tarifas;
}

}
