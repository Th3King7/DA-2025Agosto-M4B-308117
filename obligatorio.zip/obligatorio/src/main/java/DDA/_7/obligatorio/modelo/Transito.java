package DDA._7.obligatorio.modelo;

public class Transito {
private String fecha;
private String matricula;
private Categoria categorias;
private Puesto puesto;

public Transito(String fecha, String matricula, Categoria categorias, Puesto puesto) {
    this.fecha = fecha;
    this.matricula = matricula;
    this.categorias = categorias;
    this.puesto = puesto;
}

public String getFecha() {
    return fecha;
}

public String getMatricula() {
    return matricula;
}

public Categoria getCategorias() {
    return categorias;
}

public Puesto getPuesto() {
    return puesto;
}

}
