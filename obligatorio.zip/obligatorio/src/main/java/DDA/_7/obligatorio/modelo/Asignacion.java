package DDA._7.obligatorio.modelo;

import com.fasterxml.jackson.databind.annotation.JsonAppend.Prop;

public class Asignacion {
private Propietario propietario;
private Bonificacion bonificacion;
private String fechaAsignacion;

public Asignacion(Propietario propietario, Bonificacion bonificacion) {
    this.propietario = propietario;
    this.bonificacion = bonificacion;
    this.fechaAsignacion = java.time.LocalDate.now().toString();
}

public Propietario getPropietario() {
    return propietario;
}

public Bonificacion getBonificacion() {
    return bonificacion;
}

public String getFechaAsignacion() {
    return fechaAsignacion;
}

}
