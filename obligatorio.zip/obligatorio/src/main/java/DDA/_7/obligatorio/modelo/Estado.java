package DDA._7.obligatorio.modelo;

public abstract class Estado {
    private String nombreEstado;

    public Estado(String nombreEstado) {
        this.nombreEstado = nombreEstado;
    }

    public String getNombreEstado() {
        return nombreEstado;
    }

    public abstract void ingresar(Propietario p) throws Exception;
    public abstract boolean puedeTransitar();
    public abstract boolean aplicaBonificacion();
}
