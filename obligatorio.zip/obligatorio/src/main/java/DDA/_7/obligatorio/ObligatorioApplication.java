package DDA._7.obligatorio;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ObligatorioApplication {

	public static void main(String[] args) {
		SpringApplication.run(ObligatorioApplication.class, args);
	}

}
