package DDA._7.obligatorio.modelo;

import java.util.List;

public class Propietario extends Usuario {
    private double saldoActual;
    private double salodMinimoAlerta; 
    private List<Vehiculo> vehiculos;
    private List<Asignacion> asignacionBonifiaciones;
    private List<Transito> transitos;
    private List<Notificacion> notificaciones;
    private Estado estado;
    private TableroPropietario tablero;
    public Propietario(String ci, String password, String nombreCompleto, double saldoActual, double salodMinimoAlerta, List<Vehiculo> vehiculos, List<Asignacion> asignacionBonifiaciones, List<Transito> transitos, List<Notificacion> notificaciones, Estado estado) {
         super(ci, password, nombreCompleto);
         this.saldoActual = saldoActual;
         this.salodMinimoAlerta = salodMinimoAlerta;
            this.vehiculos = vehiculos;
            this.asignacionBonifiaciones = asignacionBonifiaciones;
            this.transitos = transitos;
            this.notificaciones = notificaciones;
            this.estado = estado;
            this.tablero = new TableroPropietario(this);}
public void setEstado(Estado nuevoEstado) {
        this.estado = nuevoEstado;
    }

    public void ingresarSistema() throws Exception {
        estado.ingresar(this);
    }

    public boolean puedeTransitar() {
        return estado.puedeTransitar();
    }

    public boolean aplicaBonificacion() {
        return estado.aplicaBonificacion();
    }
    public double getSaldoActual() {
        return saldoActual;
    }
    public double getSalodMinimoAlerta() {
        return salodMinimoAlerta;
    }
    public List<Vehiculo> getVehiculos() {
        return vehiculos;
    }
    public List<Asignacion> getAsignacionBonifiaciones() {
        return asignacionBonifiaciones;
    }
    public List<Transito> getTransitos() {
        return transitos;
    }
    public List<Notificacion> getNotificaciones() {
        return notificaciones;
    }
    public Estado getEstado() {
        return estado;
    }
    public TableroPropietario getTablero() {
        return tablero;
    }

    
}

