package DDA._7.obligatorio.modelo;

public class Habilitado extends Estado {
    public Habilitado() {
        super("Habilitado");
    }

    @Override
    public void ingresar(Propietario p) {
        // Puede ingresar normalmente
    }

    @Override
    public boolean puedeTransitar() {
        return true;
    }

    @Override
    public boolean aplicaBonificacion() {
        return true;
    }
}

