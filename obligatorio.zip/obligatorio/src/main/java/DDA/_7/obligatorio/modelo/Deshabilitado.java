package DDA._7.obligatorio.modelo;

public class Deshabilitado extends Estado {
    public Deshabilitado() {
        super("Deshabilitado");
    }

    @Override
    public void ingresar(Propietario p) throws Exception {
        throw new Exception("Usuario deshabilitado, no puede ingresar al sistema");
    }

    @Override
    public boolean puedeTransitar() {
        return false;
    }

    @Override
    public boolean aplicaBonificacion() {
        return false;
    }
}

