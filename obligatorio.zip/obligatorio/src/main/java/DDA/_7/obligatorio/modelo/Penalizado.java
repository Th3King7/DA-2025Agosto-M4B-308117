package DDA._7.obligatorio.modelo;

public class Penalizado extends Estado {
    public Penalizado() {
        super("Penalizado");
    }

    @Override
    public void ingresar(Propietario p) throws Exception {
        throw new Exception("El propietario se encuentra penalizado y no puede ingresar al sistema.");
    }

    @Override
    public boolean puedeTransitar() {
        return false;
    }

    @Override
    public boolean aplicaBonificacion() {
        return false;
    }

}
