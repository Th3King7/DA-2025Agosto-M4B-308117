/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DDA._7.obligatorio.modelo;
import DDA._7.obligatorio.observador.Observable;

/**
 *
 * @author PC
 */
public class Fachada extends Observable{

    public enum Eventos{listaSesiones};
    
    private SistemaAcceso sAcceso = new SistemaAcceso();
    private SistemaTransito sistemaTransito = new SistemaTransito();
    private SistemaBonificaciones sistemaBonificaciones = new SistemaBonificaciones();
    private SistemaUsuarios sistemaUsuarios = new SistemaUsuarios();
    //SINGLETON

    private static Fachada instancia = new Fachada();

    public static Fachada getInstancia() {
        return instancia;
    }
    
    private Fachada() {
    }
    //DELEGACIONES

    public Sesion loginPropietario(String ci,String pwd) throws PeajeException{
        return sAcceso.loginPropietario(ci, pwd);
    }
    public Administrador loginAdministrador(String ci,String pwd) throws PeajeException{
        return sAcceso.loginAdministrador(ci, pwd);
    }
    public void logout(Sesion sesion){
        sAcceso.getSesiones().remove(sesion);
        avisar(Eventos.listaSesiones);
    }

    public void agregarAdministrador(String ci,String pwd,String nombreCompleto){
        sAcceso.agregarAdministrador(ci, pwd, nombreCompleto);
    }
    public void agregarUsuarioPropietario(String ci, String password, String nombreCompleto, double saldoActual, double salodMinimoAlerta, java.util.List<Vehiculo> vehiculos, java.util.List<Asignacion> asignacionBonifiaciones, java.util.List<Notificacion> notificaciones){
        sAcceso.agregarUsuarioPropietario(ci, password, nombreCompleto, saldoActual, salodMinimoAlerta, vehiculos, asignacionBonifiaciones, notificaciones);
    }

  public TableroPropietario getTableroPropietario(Propietario propietario) {
        return propietario.getTablero();
    }



   

   
    
}
