package dto;

public class TableroPropietarioDto {

}
