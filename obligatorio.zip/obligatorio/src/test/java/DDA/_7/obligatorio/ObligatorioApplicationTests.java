package DDA._7.obligatorio;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ObligatorioApplicationTests {

	@Test
	void contextLoads() {
	}

}
